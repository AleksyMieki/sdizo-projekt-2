//
// Created by aleks on 13.06.22.
//

#include "List.h"

void List::createUndirectedAdjacentyList() {

    listUndirectional = new ListElement *[verticles];

    for (int i = 0; i < verticles; i++)
        listUndirectional[i] = nullptr;

    for (int i = 0; i < edgesUndirectedl; i++) {

        insideList = new ListElement;
        insideList->n = undirectedGraph[i][1];
        insideList->weight = undirectedGraph[i][2];
        insideList->next = listUndirectional[undirectedGraph[i][0]];
        listUndirectional[undirectedGraph[i][0]] = insideList;


        insideList = new ListElement;
        insideList->n = undirectedGraph[i][0];
        insideList->weight = undirectedGraph[i][2];
        insideList->next = listUndirectional[undirectedGraph[i][1]];
        listUndirectional[undirectedGraph[i][1]] = insideList;

    }
}

void List::createDirectedAdjacentyList() {

    ListDirectional = new ListElement *[verticles];

    for (int i = 0; i < verticles; i++)

        ListDirectional[i] = nullptr;

    for (int i = 0; i < edges; i++) {

        insideList = new ListElement;
        insideList->n = directedGraph[i][1];
        insideList->weight = directedGraph[i][2];
        insideList->next = ListDirectional[directedGraph[i][0]];
        ListDirectional[directedGraph[i][0]] = insideList;

    }

}

void List::printUndirectedAdjacentyList() {

    for (int i = 0; i < verticles; i++) {

        std::cout << "[" << i << "] =";
        insideList = listUndirectional[i];

        while (insideList) {

            std::cout << " " << insideList->n << "(" << insideList->weight << ")";
            insideList = insideList->next;

        }
        std::cout << std::endl;
    }

}

void List::printDirectedAdjacentyList() {

    for (int i = 0; i < verticles; i++) {
        std::cout << "[" << i << "] =>";
        insideList = ListDirectional[i];
        while (insideList) {
            std::cout << " " << insideList->n << "(" << insideList->weight << ")";
            insideList = insideList->next;
        }
        std::cout << std::endl;
    }

}

List::~List() {


    for (int i = 0; i < edges; i++) {
        delete[] directedGraph[i];
        delete[] undirectedGraph[i];
    }
    delete[]directedGraph;
    delete[]undirectedGraph;
    directedGraph = nullptr;
    undirectedGraph = nullptr;

    for (int i = 0; i < verticles; i++) {
        delete[] listUndirectional[i];
        delete[] ListDirectional[i];
    }
    delete[]listUndirectional;
    delete[]ListDirectional;
    ListDirectional = nullptr;
    listUndirectional = nullptr;

}

List::List() {

}

void List::PrimAlgorithm() {


    std::priority_queue<std::pair<int, std::pair<int, int>>, std::vector<std::pair<int, std::pair<int, int>>>, std::greater<>> queue{};

    std::vector<int> distance;

    std::vector<int> parent;

    for (int i = 0; i < edges * 2; i++) {
        distance.push_back(999);
        parent.push_back(-1);
    }

    distance.at(0) = 0;


    std::pair<int, int> pair;
    std::pair<int, std::pair<int, int>> p2;


    for(int i = 0 ; i < verticles ; i++)
    {

        ListElement* l = listUndirectional[i];

        if(listUndirectional[i]) {
            do {

                if (l->n >= i) {
                    pair = std::make_pair(i, l->n);
                    p2 = std::make_pair(l->weight, pair);

                    queue.push(p2);
                }

            } while (l = l->next);
        }
    }

//    std::vector<std::pair<int, std::pair<int, int>>> vector = getEdges(3);
//    for (int i = 0; i < vector.size(); i++)
//    {
//        queue.push(vector.at(i));
//    }
//
//    while(!queue.empty())
//    {
//        std::cout << queue.top().second.first << " " << queue.top().second.second << std::endl;
//        queue.pop();
//
//    }

    std::vector<int> nodes;

    nodes.push_back(0);

    while (!queue.empty()) {

        auto best = queue.top();
        queue.pop();


        int src = best.second.first;// source node
        int weight = best.first;
        int destination = best.second.second;

        // check for visited nodes



        auto result = std::find(nodes.begin(), nodes.end(), src);

        auto result2 = std::find(nodes.begin(), nodes.end(), destination);


        if ((result != nodes.end() && result2 == nodes.end())) {

            nodes.push_back(destination);

            std::vector<std::pair<int, std::pair<int, int>>> vector = getEdges(destination);


            for (int i = 0; i < vector.size(); i++)
            {
                queue.push(vector.at(i));
            }

            parent.at(destination) = src;
            distance.at(destination) = weight;

        }





    }



    for(int i = 0 ; i < parent.size() ; i++)
    {
        if(parent.at(i) == -1)
        {}else
            std::cout  << i << "--"<<parent.at(i) << " " << distance[i] << std::endl;
    }


}

std::vector<std::pair<int, std::pair<int, int>>> List::getEdges(int destination) {


     std::vector<std::pair<int, std::pair<int, int>>> vector;


     for(int i = 0 ; i < verticles ; i ++)
     {
         ListElement * l = listUndirectional[i];

         do
         {

             if(l->n == destination)
             {
                 vector.emplace_back(l->weight,std::make_pair(i,l->n));

             }

             if(i == destination)
             {
                 vector.emplace_back(l->weight,std::make_pair(i,l->n));

             }

         }while(l = l->next);

     }
    return vector;
}

void List::KruskalAlgorithm() {


    std::vector<std::pair<int,std::pair<int,int>>> Edges;

    int weight = 0;

    DisJointSets ds(verticles);

    for(int i = 0 ; i < verticles ; i++)
    {

        ListElement* l = listUndirectional[i];

        do
        {
            if(l->n >= i) {
                Edges.emplace_back(l->weight,std::make_pair(i,l->n));
            }

        } while (l = l->next);

    }

    std::sort(Edges.begin(),Edges.end());


    std::vector< std::pair<int,std::pair<int,int>>>::iterator it;

    for (it=Edges.begin(); it!=Edges.end(); it++)
    {
        int u = it->second.first;
        int v = it->second.second;

        int set_u = ds.find(u);
        int set_v = ds.find(v);

        // Check if the selected edge is creating
        // a cycle or not (Cycle is created if u
        // and v belong to same set)
        if (set_u != set_v)
        {


            std::cout << u << " - " << v << " " << it->first << std::endl ;


            weight += it->first;


            ds.merge(set_u, set_v);
        }
    }

}

void List::DijikstraAlgoritm(int src) {


    std::vector<int> dist(verticles, 999);

    int * PATH = new int[verticles];
    int pathPointer = 0;
    int *path = new int[verticles];

    for(int i = 0 ; i < verticles ; i ++)
    {
        path[i] = -1;
        PATH[i] = -1;

    }
    std::priority_queue<std::pair<int,int>, std::vector<std::pair<int,int>>, std::greater<>> pq;

    pq.push(std::make_pair(0,src));
    dist[src] = 0;
    //std::cout << ListDirectional[0]->n;
    while(!pq.empty()) {

        int u = pq.top().second;
        pq.pop();


        for (int i = 0; i < verticles; i++) {

           ListElement* l = ListDirectional[i];

           if(ListDirectional[i]) {
               do {

                   int v = l->n;
                   int w = l->weight;

                   if (dist[v] > dist[u] + w && i == u) {

                       dist[v] = dist[u] + w;
                       pq.push(std::make_pair(dist[v], v));
                       path[v] = u;

                   }


               } while (l = l->next);
           }
        }
    }



    for (int i = 0; i < verticles; i++) {
        std::cout << i << ": ";

        for (int j = i; j > -1 ;  j = path[j]) PATH[pathPointer++] = j; ;

        std::cout << "   | " << dist[i] << " |   ";

        while (pathPointer) std::cout << PATH[--pathPointer] << " ";

        std::cout << std::endl;

    }

    delete[] path;
    delete[] PATH;
}

void List::BellmanFordAlgorithm(int src) {


    int * PATH = new int[verticles];
    int pathPointer = 0;
    int *cost = new int[verticles];
    int *path = new int[verticles];


    for (int i = 0; i < verticles; i++) {

        cost[i] = 9999;
        path[i] = -1;

    }

    cost[src] = 0;

for(int h = 0 ; h < edges ; h++) {
    for (int i = 0; i < verticles; i++) {

        int u = 0;
        int v = 0;
        int w = 0;

        ListElement *l = ListDirectional[i];
        if (ListDirectional[i]) {
            do {

                u = i;
                v = l->n;
                w = l->weight;

                if (cost[u] != 9999 && cost[u] + w < cost[v]) {
                    cost[v] = cost[u] + w;
                    path[v] = u;
                }


            } while (l = l->next);
        }
    }
}






    std::cout << "Startowy " << src << std::endl;
    std::cout << "End    Dist    Path" << std::endl;
    for (int i = 0; i < verticles; i++) {
        std::cout << i << ": ";

        for (int j = i; j > -1; j = path[j]) PATH[pathPointer++] = j;

        std::cout << "   | " << cost[i] << " |   ";

        while (pathPointer) std::cout << PATH[--pathPointer] << " ";

        std::cout << std::endl;

    }

    delete[] cost;
    delete[] path;
    delete[] PATH;


}






