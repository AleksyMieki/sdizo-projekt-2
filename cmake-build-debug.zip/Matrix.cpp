//
// Created by aleks on 12.06.22.
//

#include "Matrix.h"

Matrix::Matrix() {


}

void Matrix::createMD() {


 directedM = new int * [edges];
 weights = new int[edges];

 for(int i = 0 ; i < edges ; i ++)
 {

     directedM[i] = new int [verticles];

     weights[i] = directedGraph[i][2];

     for(int j = 0 ; j < verticles ; j ++)
     {
         if(directedGraph[i][0] == j)
         directedM[i][j] = -1;
         else if(directedGraph[i][1] == j)
             directedM[i][j] = 1;
         else directedM[i][j] = 0;


     }

 }



}

void Matrix::printMD() {

    for(int i = 0 ; i < edges ; i ++)
    {
        std::cout << directedGraph[i][0] <<"-" <<directedGraph[i][1] <<" ";
        for(int j = 0 ; j < verticles ; j ++)
        {
            std::cout << directedM[i][j] << " ";
        }
        std::cout << " waga: " << weights[i] ;
        std::cout << std::endl;
    }

}

void Matrix::createMUD() {


    undirectedM = new int * [edgesUndirectedl];
    unWeights = new int[edgesUndirectedl];

    for(int i = 0 ; i < edgesUndirectedl ; i ++)
    {

        undirectedM[i] = new int [verticles];
        unWeights[i] = undirectedGraph[i][2];


        for(int j = 0 ; j < verticles ; j ++)
        {
            if(undirectedGraph[i][0] == j) {
                undirectedM[i][j] = 1;

            }
            else if(undirectedGraph[i][1] == j)
                undirectedM[i][j] = 1;
            else undirectedM[i][j] = 0;


        }

    }


}

void Matrix::printMUD() {



    for(int i = 0 ; i < edgesUndirectedl ; i ++)
    {


    int p = 0;
    for(int k = 0 ; k < verticles ; k ++)
    {
        if(undirectedM[i][k] == 1) {
         p++;
            std::cout << k << " ";
        }
        if(p == 2)
        {
            std::cout <<"|";
            break;
        }
    }
        for(int j = 0 ; j < verticles ; j ++)
        {
            std::cout << undirectedM[i][j] << " ";
        }
        std::cout << " waga: " << unWeights[i];
        std::cout << std::endl;
    }

}





void Matrix::Prim() {


    std::priority_queue<std::pair<int, std::pair<int, int>>, std::vector<std::pair<int, std::pair<int, int>>>, std::greater<std::pair<int, std::pair<int, int>>>> queue{};

    std::vector<int> distance;

    std::vector<int> parent;

    for (int i = 0; i < edges*2 ; i++) {
        distance.push_back(999);
        parent.push_back(-1);
    }

    distance.at(0) = 0;



    for (int i = 0; i < edgesUndirectedl; i++) {
        int p = 0;

        std::pair<int, int> pair;
        std::pair<int, std::pair<int, int>> p2;

        for (int j = 0; j < verticles; j++) {

            if (undirectedM[i][j] == 1 && p == 0) {

                pair.first = j;
                p++;

            } else if (undirectedM[i][j] == 1) {

                pair.second = j;

                p2.first = unWeights[i];
                p2.second = pair;
                queue.push(p2);

                break;
            }

        }

    }


    std::vector<int> nodes;


    int ans = 0;

    nodes.push_back(0);

    while (!queue.empty()) {

        auto best = queue.top();
        queue.pop();


        int src = best.second.first;// source node
        int weight = best.first;
        int destination = best.second.second;
        // check for visited nodes



        auto result = std::find(nodes.begin(), nodes.end(), src);

        auto result2 = std::find(nodes.begin(), nodes.end(), destination);


        if ((result != nodes.end() && result2 == nodes.end())) {

            nodes.push_back(destination);


            std::vector<std::pair<int, std::pair<int, int>>> vector = getEdges(destination);

            for (int i = 0; i < vector.size(); i++)
            {
                queue.push(vector.at(i));
            }
            parent.at(destination) = src;
            distance.at(destination) = weight;
        }





    }


    for(int i = 0 ; i < parent.size() ; i++)
    {
        if(parent.at(i) == -1)
        {}else
        std::cout  << i << "--"<<parent.at(i) << " " << distance[i] << std::endl;
    }
}





std::vector<std::pair<int, std::pair<int, int>>> Matrix::getEdges(int destination) {



     std::vector<std::pair<int, std::pair<int, int>>> vector;

    for(int i = 0 ; i < edgesUndirectedl ; i++)
    {
        int p = 0;
        int k = 0;

        for(int j = 0 ; j < verticles ; j++) {


            if(undirectedM[i][j] == 1 && j == destination)
            {
                k = j;
                p++;
            }
             if( undirectedM[i][j] == 1 && k!=j && p == 1)
            {
                vector.emplace_back(unWeights[i],std::make_pair(k,j));
                break;
            }
        }

    }
    for(int i = 0 ; i < edgesUndirectedl ; i++)
    {
        int p = 0;
        int k = 0;
        for(int j = 0 ; j < verticles ; j++) {


            if(undirectedM[i][j] == 1 && p == 0)
            {
                k = j;
                p++;
            }
            if( undirectedM[i][j] == 1 && destination == j  && p == 1 && k!=j)
            {
                vector.emplace_back(unWeights[i],std::make_pair(j,k));
                break;
            }
        }

    }


    return vector;
}

void Matrix::Kruskal() {

    std::vector<std::pair<int,std::pair<int,int>>> Edges;

    int weight = 0;
    int *cost = new int[verticles];

    DisJointSets ds(verticles);

    for (int i = 0; i < edgesUndirectedl; i++) {
        int p = 0;

        std::pair<int, int> pair;
        std::pair<int, std::pair<int, int>> p2;

        for (int j = 0; j < verticles; j++) {

            if (undirectedM[i][j] == 1 && p == 0) {

                pair.first = j;
                p++;

            } else if (undirectedM[i][j] == 1) {

                pair.second = j;

                p2.first = unWeights[i];
                p2.second = pair;
                 Edges.push_back(p2);

                break;
            }

        }

    }

    std::sort(Edges.begin(),Edges.end());
//        for(int i = 0 ; i < Edges.size() ; i++)
//        {
//            std::cout << Edges.at(i).second.first <<" " << Edges.at(i).second.second << std::endl;
//        }
    std::vector< std::pair<int,std::pair<int,int>>>::iterator it;

    for (it=Edges.begin(); it!=Edges.end(); it++)
    {
        int u = it->second.first;
        int v = it->second.second;

        int set_u = ds.find(u);
        int set_v = ds.find(v);


        if (set_u != set_v)
        {


            std::cout << u << " - " << v << " " << it->first << std::endl ;


            weight += it->first;


            ds.merge(set_u, set_v);
        }
    }

}

void Matrix::Dijkstra(int src) {



    std::vector<int> dist(verticles, 9999);
    int * PATH = new int[verticles];
    int pathPointer = 0;
    int *path = new int[verticles];

    for(int i = 0 ; i < verticles ; i ++)
    {
        path[i] = -1;
        PATH[i] = -1;
    }
    std::priority_queue<std::pair<int,int>, std::vector<std::pair<int,int>>, std::greater<>> pq;

    pq.push(std::make_pair(0,src));
    dist[src] = 0;

    while(!pq.empty())
    {
        int u = pq.top().second;
        pq.pop();

        for(int i = 0 ; i < edges ; i++)
        {
            int k = 0 ;
            int p = 0;
            int l = 0;
            int w2 = 0;
            for(int j = 0 ; j < verticles ; j++)
            {
                if( directedM[i][j] == -1  && j == u)
                {
                    p++;

                }
                if(p == 1 && directedM[i][j] == 1)
                {

                    int v = j;
                    int w = weights[i];

                    if(dist[v] > dist[u] + w )
                    {

                        dist[v] =  dist[u] + w ;
                        pq.push(std::make_pair(dist[v], v));
                        path[v] = u;

                    }

                }
                if(directedM[i][j] == 1  && p==0 )
                {

                    l = j;
                    k++;
                    w2 = weights[i];

                }
                if(k == 1 && directedM[i][j] == -1 && j == u )
                {



                    if(dist[l] > dist[u] + w2)
                    {

                        dist[l] = dist[u] + w2 ;
                        pq.push(std::make_pair(dist[l], l));
                        path[l] = u;


                    }
                }


            }

        }
    }


    for (int i = 0; i < verticles; i++) {
        std::cout << i << ": ";

        for (int j = i; j > -1 ;  j = path[j]) PATH[pathPointer++] = j; ;

        std::cout << "   | " << dist[i] << " |   ";

        while (pathPointer) std::cout << PATH[--pathPointer] << " ";

        std::cout << std::endl;

    }

}

void Matrix::BellmanFord(int src) {


    int * PATH = new int[verticles];
    int pathPointer = 0;
    int *cost = new int[verticles];
    int *path = new int[verticles];


    for (int i = 0; i < verticles; i++) {

        cost[i] = 9999;
        path[i] = -1;

    }


    cost[src] = 0;


        for (int k = 0; k < verticles - 1; k++) {

            for (int i = 0; i < edges; i++) {

                int u = 0;
                int p = 0;
                int v = 0;
                int w = 0;
                int s = 0;
                int w2 = 0;

                for (int j = 0; j < verticles; j++) {


                    if (directedM[i][j] == -1 && s == 0) {

                        u = j;
                        p++;

                    }
                    if (p == 1 && directedM[i][j] == 1 && s == 0) {

                        v = j;
                        w = weights[i];
                        p++;

                    }
                    if (cost[u] != 9999 && cost[u] + w < cost[v] && p == 2) {

                        cost[v] = cost[u] + w;
                        path[v] = u;

                    }

                    if (directedM[i][j] == 1 && p == 0) {


                        v = j;
                        s++;

                    }
                    if (s == 1 && directedM[i][j] == -1) {


                        w2 = weights[i];

                        u = j;
                        s++;

                    }
                    if (cost[u] != 9999 && cost[u] + w2 < cost[v] && s == 2) {

                        cost[v] = cost[u] + w2;
                        path[v] = u;

                    }


                }
            }
        }




    std::cout << "Startowy " << src << std::endl;
    std::cout << "End    Dist    Path" << std::endl;
    for (int i = 0; i < verticles; i++) {
        std::cout << i << ": ";

        for (int j = i; j > -1; j = path[j]) PATH[pathPointer++] = j;

        std::cout << "   | " << cost[i] << " |   ";

        while (pathPointer) std::cout << PATH[--pathPointer] << " ";

        std::cout << std::endl;

    }

    delete[] cost;
    delete[] path;
    delete[] PATH;

}

Matrix::~Matrix() {

    for (int i = 0; i < edges; i++) {
        delete[] directedGraph[i];
        delete[] undirectedGraph[i];
    }
    delete[]directedGraph;
    delete[]undirectedGraph;
    directedGraph = nullptr;
    undirectedGraph = nullptr;

    for (int i = 0; i < verticles; i++) {
        delete[] directedM[i];
        delete[] undirectedM[i];
    }

    delete[] directedM;
    delete[] undirectedM;
    directedM = nullptr;
    undirectedM = nullptr;
}




