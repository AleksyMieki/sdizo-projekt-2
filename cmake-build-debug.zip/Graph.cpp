//
// Created by aleks on 12.06.22.
//

#include "Graph.h"

Graph::Graph() {

}



void Graph::createDirectedGraph(std::string filename) {


    int source = 0, destination = 0, weight = 0 ;
    std::fstream myfile(filename , std::ios::in);

    if(myfile.is_open())
    {
        myfile >> edges;
        myfile >> verticles;

        directedGraph = new int*[edges];



        for(int i = 0 ; i  < edges ; i++)
        {
            myfile >> source;
            myfile >> destination;
            myfile >> weight;

            directedGraph[i] = new int[3];
            directedGraph[i][0] = source;
            directedGraph[i][1] = destination;
            directedGraph[i][2] = weight;

        }

        myfile.close();
    }


}
void Graph::createUndirectedGraph()
{
    bool *duplicate;
    duplicate = new bool[edges];

    for (int i = 0; i < edges; i++)
        duplicate[i] = false;

    undirectedGraph = new int *[edges];

    for (int i = 0; i < edges; i++)
        undirectedGraph[i] = nullptr;

    for (int i = 0; i < edges; i++) {
        for (int j = 0; j < i; j++) {
            if ((directedGraph[i][0] == directedGraph[j][0] && directedGraph[i][1] == directedGraph[j][1]) || (directedGraph[i][1] == directedGraph[j][0] && directedGraph[i][0] == directedGraph[j][1])) {
                duplicate[i] = false;
                break;
            }
            duplicate[i] = true;
        }
    }

    duplicate[0] = true;
    edgesUndirectedl= 0;

    for (int i = 0; i < edges; i++) {
        if (duplicate[i]) {

            undirectedGraph[edgesUndirectedl] = new int[3];
            undirectedGraph[edgesUndirectedl][0] = directedGraph[i][0];
            undirectedGraph[edgesUndirectedl][1] = directedGraph[i][1];
            undirectedGraph[edgesUndirectedl][2] = directedGraph[i][2];

            edgesUndirectedl++;

        }
    }

}

void Graph::print() {

    std::cout << directedGraph[0][2] << directedGraph[1][1];

}

void Graph::generateRandomGraph() {

    srand(time(nullptr));

    int node_count =0;
    float density = 0;
    std::cout <<"podaj ilosc wierzcholkow: ";
    std::cin >> node_count;
    std::cout << std::endl;
    std::cout <<"podaj gestosc grafu: ";
    std::cin >> density;
    std::vector<std::pair<int,std::pair<int,int>>> edges;

    int i = 0;
    int edges_count = static_cast<int>((density*node_count *(node_count-1)) /2);
    int rand_node = rand() % node_count;

    std::vector<int> weights;
    std::vector<std::pair<int,int>> edgesPresent;

    for(; i < node_count; i++)
    {
        int w = (rand()%1000)+1;
        if(i != rand_node && weights.end() == std::find(weights.begin(),weights.end(),w))
        {

            weights.push_back(w);
            edgesPresent.push_back(std::make_pair(rand_node,i));
            edges.emplace_back(w,std::make_pair(rand_node,i));
        }
    }
    for(; i < edges_count; )
    {
        int e1 = rand()% node_count;
        int e2 = rand() % node_count;
        int w = (rand()%1000)+1;

    if(edges.end() ==   std::find(edges.begin(), edges.end(),std::make_pair(w,std::make_pair(e1,e2))) && e1!=e2 && weights.end() == std::find(weights.begin(),weights.end(),w) && edgesPresent.end() == std::find(edgesPresent.begin(),edgesPresent.end(), std::make_pair(e1,e2)))
    {
        edges.emplace_back(std::make_pair(w, std::make_pair(e1, e2)));
        edgesPresent.push_back(std::make_pair(e1,e2));
        i++;
    }
    }

    std::fstream plik("plik.txt", std::ios::out);				//wpisuje do pliku
    if (plik.good()) {
        plik << edges.size() << " " << node_count  << "\n";
        for (int j = 0; j < edges.size(); j++)	plik << edges.at(j).second.first << " " << edges.at(j).second.second << " " << edges.at(j).first << "\n";
        plik.close();
    }

}
