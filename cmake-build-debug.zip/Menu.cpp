//
// Created by aleks on 13.06.22.
//

#include "Menu.h"

Menu::Menu() {

    matrix.createDirectedGraph("graph.txt");
    matrix.createUndirectedGraph();
    matrix.createMD();
    matrix.createMUD();

    list.createDirectedGraph("graph.txt");
    list.createUndirectedGraph();
    list.createDirectedAdjacentyList();
    list.createUndirectedAdjacentyList();




}

//TODO source dla dijkstry i bellmana

void Menu::mFunctions() {

    bool petla = true;

    while(petla) {
        std::cout <<  "Funkcje dla macierzy:\n1.Prim\n2.Kruskal\n3.Dijkstra\n4.Bellman\n5.Wyswietl macierz skierowana\n6.Wyswietl macierz nieskierowana\n7.Exit\n";
        int i = 0 ;
        int k = 0;

        std::cout << "wybor: ";
        std::cin >> i;
        std::cout << std::endl;
        switch (i) {

            case 1:
                matrix.Prim();
                break;
            case 2:
                matrix.Kruskal();
                break;
            case 3:
                std::cout <<"podaj wierzcholek startowy: ";
                std::cin >> k;
                matrix.Dijkstra(k);
                break;
            case 4:
                std::cout <<"podaj wierzcholek startowy: ";
                std::cin >> k;
                matrix.BellmanFord(k);
                break;
            case 5:
                matrix.printMD();
                break;
            case 6:
                matrix.printMUD();
                break;
            case 7:
                petla = false;
                break;
            default:
                petla = false;
                break;

        }

    }
}

void Menu::lFunctions() {

    bool petla = true;
//TODO
    while (petla) {
        std::cout << "Funkcje dla listy:\n1.Prim\n2.Kruskal\n3.Dijkstra\n4.Bellman\n5.Wyswietl liste skierowana\n6.Wyswietl liste nieskierowana\n7.Exit\n";
        int i = 0;
        int k = 0;
        std::cout << "wybor: ";
        std::cin >> i;
        std::cout << std::endl;
        switch (i) {

            case 1:
                list.PrimAlgorithm();
                break;
            case 2:
                list.KruskalAlgorithm();
                break;
            case 3:
                std::cout <<"podaj wierzcholek startowy: ";
                std::cin >> k;
                list.DijikstraAlgoritm(k);
                break;
            case 4:
                std::cout <<"podaj wierzcholek startowy: ";
                std::cin >> k;
                list.BellmanFordAlgorithm(k);
                break;
            case 5:
                list.printDirectedAdjacentyList();
                break;
            case 6:
                list.printUndirectedAdjacentyList();
                break;
            case 7:
                petla = false;
                break;
            default:
                petla = false;
                break;

        }
    }

}

void Menu::mainMenu() {

    bool petla = true;

    while(petla)
    {
        std::cout << "Opcje programu: \n1.Wygeneruj graf losowo\n2.Wczytaj graf z pliku\n3.Funkcje macierzy\n4.Funkcje listy\n5.Wylacz\n";
        int m = 0 ;
        std::cout <<"wybor: ";

        std::cin >> m;

        
        switch (m) {

            case 1:

                Graph::generateRandomGraph();
                matrix.createDirectedGraph("plik.txt");
                matrix.createUndirectedGraph();
                matrix.createMD();
                matrix.createMUD();

                list.createDirectedGraph("plik.txt");
                list.createUndirectedGraph();
                list.createDirectedAdjacentyList();
                list.createUndirectedAdjacentyList();
                break;

            case 2:
                matrix.createDirectedGraph("graph.txt");
                matrix.createUndirectedGraph();
                matrix.createMD();
                matrix.createMUD();

                list.createDirectedGraph("graph.txt");
                list.createUndirectedGraph();
                list.createDirectedAdjacentyList();
                list.createUndirectedAdjacentyList();

                break;

            case 3:
                mFunctions();
                break;
            case 4:
                lFunctions();
                break;
            case 5:
                petla = false;
                break;
            default:
                petla = false;
                break;

        }

    }

}
