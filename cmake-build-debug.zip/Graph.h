//
// Created by aleks on 12.06.22.
//

#ifndef SDIZO_TREES_GRAPH_H
#define SDIZO_TREES_GRAPH_H
#include "fstream"
#include "iostream"
#include "ios"
#include "DisJointSets.h"
#include <cmath>
#include "vector"
#include "algorithm"
class Graph : public DisJointSets{


protected:


    //variables
    int ** directedGraph;
    int ** undirectedGraph;
    int edges;
    int verticles;

    int edgesUndirectedl;

public:

    //constructor and destructor
    Graph();
  //  ~Graph();

    //function for generating a random graph
    static void generateRandomGraph();


    //functions for generating graphs
    void createDirectedGraph(std::string);
    void createUndirectedGraph();

    //function for reading data from file
    void readDataFromFile();
    void print();


};


#endif //SDIZO_TREES_GRAPH_H
