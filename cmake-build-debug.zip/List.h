//
// Created by aleks on 13.06.22.
//

#ifndef SDIZO_TREES_LIST_H
#define SDIZO_TREES_LIST_H
#include "Graph.h"
#include "queue"
#include "ctime"
#include "list"
#include "set"
#include "array"
#include "algorithm"
#include <cstdlib>


class List : public Graph{

    struct ListElement {

        ListElement *next;
        int n;
        int weight;

    };


private:
    ListElement **listUndirectional;
    ListElement **ListDirectional, *insideList;
public:

    ~List();
    List();
    void createUndirectedAdjacentyList();
    void createDirectedAdjacentyList();
    void printUndirectedAdjacentyList();
    void printDirectedAdjacentyList();
    void PrimAlgorithm();
    void KruskalAlgorithm();
    std::vector<std::pair<int,std::pair<int,int>>> getEdges(int destination);

    void DijikstraAlgoritm(int);
    void BellmanFordAlgorithm(int);

};


#endif //SDIZO_TREES_LIST_H
