//
// Created by aleks on 12.06.22.
//

#ifndef SDIZO_TREES_EDGE_H
#define SDIZO_TREES_EDGE_H

#endif //SDIZO_TREES_EDGE_H

struct Edge{


public:

    int from;
    int to ;
    int weight;

    bool operator < (const Edge& edge) const
    {
        return weight > edge.weight;
    }

    bool operator == (const Edge& edge) const
    {
        return from == edge.from && to == edge.to;
    }

    bool opposite(const Edge& edge) const
    {
        return from == edge.to && to == edge.from;
    }
};