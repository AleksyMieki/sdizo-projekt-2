//
// Created by aleks on 13.06.22.
//

#ifndef SDIZO_TREES_MENU_H
#define SDIZO_TREES_MENU_H
#include "Graph.h"
#include "List.h"
#include "Matrix.h"


class Menu {

private:

    Graph graph;
    Matrix matrix;
    List list;

public:

    Menu();

//    void printMD() { matrix.printMD(); }
//    void printMUD() { matrix.printMUD(); }
//
//    void printLD() { list.printDirectedAdjacentyList(); }
//    void printLUD() { list.printUndirectedAdjacentyList(); }
//
//    void matrixPrim() { matrix.Prim(); }
//    void matrixKruskal() { matrix.Kruskal(); }
//    void matrixDijkstra() { matrix.Dijkstra(); }
//    void matrixBellman() { matrix.BellmanFord(); }
//
//    void listPrim(){ list.PrimAlgorithm(); }
//    void listKruskal() { list.KruskalAlgorithm(); }
//    void listDijkstra() { list.DijikstraAlgoritm(); }
//    void listBellman() { list.BellmanFordAlgorithm(); }

    void mFunctions();
    void lFunctions();

    void mainMenu();




};


#endif //SDIZO_TREES_MENU_H
