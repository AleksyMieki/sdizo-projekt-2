#include <iostream>
#include "Menu.h"
#include "random"
#include "cstdlib"


int main() {

    Menu menu;

    menu.mainMenu();

//TimeMeasures timeMeasures(200,0.99);
//
//        std::cout << "MATRIX " << timeMeasures.getV() << " "<< timeMeasures.getDensity() <<std::endl;
//
//        std::cout <<  timeMeasures.MPRIM() << std::endl;
//        std::cout <<  timeMeasures.MKRUSKAL() << std::endl;
//        std::cout <<  timeMeasures.MDIJKSTRA() << std::endl;
//        std::cout <<  timeMeasures.MDBELLMAN() << std::endl;
//
//        std::cout << "LIST " << timeMeasures.getV() << " "<< timeMeasures.getDensity() <<std::endl;
//        std::cout << timeMeasures.LPRIM() << std::endl;
//        std::cout << timeMeasures.LKRUSKAL() << std::endl;
//        std::cout << timeMeasures.LDIJKSTRA() << std::endl;
//        std::cout << timeMeasures.LDBELLMAN() << std::endl;



    return  0;

    //TODO dodac wagi do matrix directed i wizualnie poprawic
}
