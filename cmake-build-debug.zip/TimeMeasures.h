//
// Created by aleks on 14.06.22.
//

#ifndef SDIZO_TREES_TIMEMEASURES_H
#define SDIZO_TREES_TIMEMEASURES_H

#include "chrono"
#include "vector"
#include "Matrix.h"
#include "Graph.h"
#include "List.h"

typedef unsigned long long timedata;

class TimeMeasures: public Matrix, public List{

    int repeats = 20;
    float density = 0.99;
    int v = 100;

    class AveragedTimeMeasure {
        std::chrono::high_resolution_clock::time_point start, end;
        std::chrono::duration<double> elapsed = std::chrono::duration<double>::zero();
        std::size_t times = 0;


    public:
        void benchmarkStart()
        {
            start = std::chrono::high_resolution_clock::now();
        }

        void benchmarkStop()
        {
            end = std::chrono::high_resolution_clock::now();

            elapsed += end - start;
            times++;
        }

        timedata getAvgElapsedNsec()
        {
            return std::chrono::duration_cast<std::chrono::nanoseconds>(elapsed).count() / times;
        }
    };



public:

    TimeMeasures(int verticles,float d): v(verticles), density(d) {};

    unsigned long long MPRIM();
    unsigned long long MKRUSKAL();
    unsigned long long MDIJKSTRA();
    unsigned long long MDBELLMAN();

    unsigned long long LPRIM();
    unsigned long long LKRUSKAL();
    unsigned long long LDIJKSTRA();
    unsigned long long LDBELLMAN();

    int getV() const
    {
        return v;
    }
    float getDensity() const
    {
        return density;
    }
};


#endif //SDIZO_TREES_TIMEMEASURES_H
