//
// Created by aleks on 14.06.22.
//

#include "TimeMeasures.h"

unsigned long long TimeMeasures::MPRIM() {

    AveragedTimeMeasure timeMeasure;
    Matrix matrix;



    for(int i = 0 ; i < 5 ; i++) {
        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");
        matrix.createUndirectedGraph();
        matrix.createMUD();
        timeMeasure.benchmarkStart();
        matrix.Prim();
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}

unsigned long long TimeMeasures::MKRUSKAL() {

    AveragedTimeMeasure timeMeasure;
    Matrix matrix;



    for(int i = 0 ; i < repeats ; i++) {
        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");
        matrix.createUndirectedGraph();
        matrix.createMUD();
        timeMeasure.benchmarkStart();
        matrix.Kruskal();
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}

unsigned long long TimeMeasures::MDIJKSTRA() {

    AveragedTimeMeasure timeMeasure;
    Matrix matrix;

    for(int i = 0 ; i < repeats ; i++) {
        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");
        matrix.createMD();
        timeMeasure.benchmarkStart();
        matrix.Dijkstra(0);
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}

unsigned long long TimeMeasures::MDBELLMAN() {
    AveragedTimeMeasure timeMeasure;
    Matrix matrix;

    for(int i = 0 ; i < repeats ; i++) {
        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");
        matrix.createMD();
        timeMeasure.benchmarkStart();
        matrix.BellmanFord(0);
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}

unsigned long long TimeMeasures::LPRIM() {

    AveragedTimeMeasure timeMeasure;
    List matrix;



    for(int i = 0 ; i < repeats ; i++) {
        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");
        matrix.createUndirectedGraph();
        matrix.createUndirectedAdjacentyList();
        timeMeasure.benchmarkStart();
        matrix.PrimAlgorithm();
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}

unsigned long long TimeMeasures::LKRUSKAL() {
    AveragedTimeMeasure timeMeasure;
    List matrix;



    for(int i = 0 ; i < repeats ; i++) {
        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");
        matrix.createUndirectedGraph();
        matrix.createUndirectedAdjacentyList();
        timeMeasure.benchmarkStart();
        matrix.KruskalAlgorithm();
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}

unsigned long long TimeMeasures::LDIJKSTRA() {

    AveragedTimeMeasure timeMeasure;
    List matrix;



    for(int i = 0 ; i < repeats ; i++) {

        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");

        matrix.createDirectedAdjacentyList();
        timeMeasure.benchmarkStart();
        matrix.DijikstraAlgoritm(0);
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}

unsigned long long TimeMeasures::LDBELLMAN() {
    AveragedTimeMeasure timeMeasure;
    List matrix;



    for(int i = 0 ; i < repeats ; i++) {

        matrix.generateRandomGraph(v,density);
        matrix.createDirectedGraph("plik.txt");

        matrix.createDirectedAdjacentyList();
        timeMeasure.benchmarkStart();
        matrix.BellmanFordAlgorithm(0);
        timeMeasure.benchmarkStop();
    }
    return timeMeasure.getAvgElapsedNsec();
}
