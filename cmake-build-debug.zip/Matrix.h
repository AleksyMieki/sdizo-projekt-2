//
// Created by aleks on 12.06.22.
//

#ifndef SDIZO_TREES_MATRIX_H
#define SDIZO_TREES_MATRIX_H
#include "vector"
#include "Graph.h"
#include "queue"
#include "Edge.h"
#include "ctime"
#include "list"
#include "set"
#include "array"
#include "algorithm"
#include <cstdlib>

class Matrix : public Graph, public Edge{



private:

int** directedM;
int** undirectedM;

int *weights;
int *unWeights;

public:

    Matrix();
    ~Matrix();

    void createMD();
    void createMUD();

    void printMD();
    void printMUD();

    void Prim();
    std::vector<std::pair<int,std::pair<int,int>>> getEdges(int destination);
    void Kruskal();


    void Dijkstra(int);
    void BellmanFord(int);

};


#endif //SDIZO_TREES_MATRIX_H
